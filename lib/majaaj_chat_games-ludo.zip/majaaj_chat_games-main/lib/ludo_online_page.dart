import 'dart:math';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

class LudoOnlinePage extends StatefulWidget {
  const LudoOnlinePage({super.key});

  @override
  State<LudoOnlinePage> createState() => _LudoOnlinePageState();
}

class _LudoOnlinePageState extends State<LudoOnlinePage> {
  final _db = FirebaseFirestore.instance;
  final _auth = FirebaseAuth.instance;
  final _codeController = TextEditingController();
  bool _busy = false;
  String? _gameId;

  CollectionReference<Map<String, dynamic>> get _games => _db.collection('ludo_games');

  @override
  void dispose() {
    _codeController.dispose();
    super.dispose();
  }

  String get _uid => _auth.currentUser?.uid ?? '';
  String get _name => _auth.currentUser?.displayName?.trim().isNotEmpty == true
      ? _auth.currentUser!.displayName!.trim()
      : 'لاعب';

  Future<void> createGame(int maxPlayers) async {
    if (_uid.isEmpty) return _error('يجب تسجيل الدخول أولاً');
    setState(() => _busy = true);
    try {
      final ref = _games.doc();
      await ref.set({
        'gameId': ref.id,
        'status': 'waiting',
        'maxPlayers': maxPlayers,
        'createdBy': _uid,
        'currentPlayer': '',
        'dice': 0,
        'winner': '',
        'turnNumber': 0,
        'players': {
          _uid: {
            'uid': _uid,
            'name': _name,
            'color': 'red',
            'pieces': [-1, -1, -1, -1],
          }
        },
        'createdAt': FieldValue.serverTimestamp(),
        'updatedAt': FieldValue.serverTimestamp(),
      });
      if (!mounted) return;
      setState(() => _gameId = ref.id);
    } catch (e) {
      _error('تعذر إنشاء اللعبة: $e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> joinGame() async {
    if (_uid.isEmpty) return _error('يجب تسجيل الدخول أولاً');
    final code = _codeController.text.trim();
    if (code.isEmpty) return _error('اكتب رمز اللعبة');
    setState(() => _busy = true);
    try {
      final ref = _games.doc(code);
      await _db.runTransaction((tx) async {
        final snap = await tx.get(ref);
        if (!snap.exists) throw Exception('اللعبة غير موجودة');
        final data = snap.data()!;
        if (data['status'] != 'waiting') throw Exception('اللعبة بدأت بالفعل');

        final players = Map<String, dynamic>.from(data['players'] ?? {});
        if (players.containsKey(_uid)) return;
        final maxPlayers = ((data['maxPlayers'] ?? 2) as num).toInt();
        if (players.length >= maxPlayers) throw Exception('اللعبة مكتملة');

        const colors = ['red', 'green', 'yellow', 'blue'];
        final used = players.values
            .map((e) => Map<String, dynamic>.from(e as Map)['color']?.toString())
            .whereType<String>()
            .toSet();
        final color = colors.firstWhere((c) => !used.contains(c));
        players[_uid] = {
          'uid': _uid,
          'name': _name,
          'color': color,
          'pieces': [-1, -1, -1, -1],
        };

        final newStatus = players.length == maxPlayers ? 'playing' : 'waiting';
        String current = data['currentPlayer']?.toString() ?? '';
        if (newStatus == 'playing' && current.isEmpty) current = players.keys.first;

        tx.update(ref, {
          'players': players,
          'status': newStatus,
          'currentPlayer': current,
          'turnNumber': newStatus == 'playing' ? 1 : 0,
          'updatedAt': FieldValue.serverTimestamp(),
        });
      });
      if (!mounted) return;
      setState(() => _gameId = code);
    } catch (e) {
      _error(e.toString().replaceFirst('Exception: ', ''));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> rollDice(Map<String, dynamic> game) async {
    if (_busy || _uid.isEmpty) return;
    final ref = _games.doc(game['gameId'].toString());
    setState(() => _busy = true);
    try {
      await _db.runTransaction((tx) async {
        final snap = await tx.get(ref);
        if (!snap.exists) throw Exception('اللعبة غير موجودة');
        final data = snap.data()!;
        if (data['status'] != 'playing') throw Exception('اللعبة ليست قيد اللعب');
        if (data['currentPlayer'] != _uid) throw Exception('مو دورك');
        final oldDice = ((data['dice'] ?? 0) as num).toInt();
        if (oldDice != 0) throw Exception('حرّك حجرك أولاً');
        final value = Random().nextInt(6) + 1;
        tx.update(ref, {'dice': value, 'updatedAt': FieldValue.serverTimestamp()});
      });
    } catch (e) {
      _error(e.toString().replaceFirst('Exception: ', ''));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> movePiece(Map<String, dynamic> game, int pieceIndex) async {
    if (_busy || _uid.isEmpty) return;
    final ref = _games.doc(game['gameId'].toString());
    setState(() => _busy = true);
    try {
      await _db.runTransaction((tx) async {
        final snap = await tx.get(ref);
        if (!snap.exists) throw Exception('اللعبة غير موجودة');
        final data = snap.data()!;
        if (data['status'] != 'playing') throw Exception('اللعبة انتهت');
        if (data['currentPlayer'] != _uid) throw Exception('مو دورك');
        final dice = ((data['dice'] ?? 0) as num).toInt();
        if (dice == 0) throw Exception('ارمِ النرد أولاً');

        final players = Map<String, dynamic>.from(data['players'] ?? {});
        final me = Map<String, dynamic>.from(players[_uid] ?? {});
        final pieces = List<int>.from((me['pieces'] ?? [-1, -1, -1, -1]).map((e) => (e as num).toInt()));
        if (pieceIndex < 0 || pieceIndex >= 4) throw Exception('حجر غير صالح');

        final old = pieces[pieceIndex];
        if (!_legalMove(old, dice)) throw Exception('ما تكدر تحرك هذا الحجر');
        final next = old == -1 ? 0 : old + dice;
        pieces[pieceIndex] = next;
        me['pieces'] = pieces;
        players[_uid] = me;

        if (next >= 0 && next <= 51 && !_isSafeGlobal(_globalPosition(_colorOf(me), next))) {
          final hitGlobal = _globalPosition(_colorOf(me), next);
          for (final entry in players.entries) {
            if (entry.key == _uid) continue;
            final other = Map<String, dynamic>.from(entry.value);
            final otherPieces = List<int>.from((other['pieces'] ?? [-1, -1, -1, -1]).map((e) => (e as num).toInt()));
            final otherColor = other['color']?.toString() ?? 'red';
            bool changed = false;
            for (var i = 0; i < otherPieces.length; i++) {
              final p = otherPieces[i];
              if (p >= 0 && p <= 51 && _globalPosition(otherColor, p) == hitGlobal) {
                otherPieces[i] = -1;
                changed = true;
              }
            }
            if (changed) {
              other['pieces'] = otherPieces;
              players[entry.key] = other;
            }
          }
        }

        final won = pieces.every((p) => p == 57);
        String nextPlayer = data['currentPlayer'].toString();
        String status = data['status'].toString();
        if (won) {
          status = 'finished';
        } else if (dice != 6) {
          nextPlayer = _nextPlayer(players, _uid);
        }

        tx.update(ref, {
          'players': players,
          'dice': 0,
          'currentPlayer': nextPlayer,
          'status': status,
          'winner': won ? _uid : '',
          'turnNumber': ((data['turnNumber'] ?? 0) as num).toInt() + (dice == 6 || won ? 0 : 1),
          'updatedAt': FieldValue.serverTimestamp(),
        });
      });
    } catch (e) {
      _error(e.toString().replaceFirst('Exception: ', ''));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  bool _legalMove(int position, int dice) {
    if (position == 57) return false;
    if (position == -1) return dice == 6;
    return position + dice <= 57;
  }

  String _colorOf(Map<String, dynamic> player) => player['color']?.toString() ?? 'red';

  String _nextPlayer(Map<String, dynamic> players, String uid) {
    final ids = players.keys.toList();
    if (ids.isEmpty) return uid;
    final index = ids.indexOf(uid);
    return ids[(index + 1) % ids.length];
  }

  int _startOffset(String color) {
    switch (color) {
      case 'green': return 13;
      case 'yellow': return 26;
      case 'blue': return 39;
      default: return 0;
    }
  }

  int _globalPosition(String color, int position) => (_startOffset(color) + position) % 52;

  bool _isSafeGlobal(int p) => const {0, 8, 13, 21, 26, 34, 39, 47}.contains(p);

  void _error(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
  }

  @override
  Widget build(BuildContext context) {
    if (_gameId != null) return _gameStream(_gameId!);
    return Scaffold(
      appBar: AppBar(title: const Text('🎲 لودو مزاج')),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            const SizedBox(height: 20),
            const Text('لودو أونلاين', style: TextStyle(fontSize: 30, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            const Text('العب ويا أصدقائك مباشرة عبر الإنترنت'),
            const SizedBox(height: 30),
            FilledButton.icon(
              onPressed: _busy ? null : () => _choosePlayers(),
              icon: const Icon(Icons.add),
              label: const Text('إنشاء لعبة'),
            ),
            const SizedBox(height: 18),
            TextField(
              controller: _codeController,
              textAlign: TextAlign.center,
              decoration: const InputDecoration(labelText: 'رمز اللعبة', border: OutlineInputBorder()),
            ),
            const SizedBox(height: 12),
            OutlinedButton.icon(
              onPressed: _busy ? null : joinGame,
              icon: const Icon(Icons.login),
              label: const Text('دخول إلى لعبة'),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _choosePlayers() async {
    final count = await showDialog<int>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('عدد اللاعبين'),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          ListTile(title: const Text('لاعبين 2'), onTap: () => Navigator.pop(context, 2)),
          ListTile(title: const Text('لاعبين 4'), onTap: () => Navigator.pop(context, 4)),
        ]),
      ),
    );
    if (count != null) await createGame(count);
  }

  Widget _gameStream(String id) {
    return StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
      stream: _games.doc(id).snapshots(),
      builder: (context, snapshot) {
        if (snapshot.hasError) return Scaffold(body: Center(child: Text('خطأ: ${snapshot.error}')));
        if (!snapshot.hasData || !snapshot.data!.exists) return const Scaffold(body: Center(child: CircularProgressIndicator()));
        final game = snapshot.data!.data()!;
        if (game['status'] == 'waiting') return _waitingScreen(game);
        return _boardScreen(game);
      },
    );
  }

  Widget _waitingScreen(Map<String, dynamic> game) {
    final players = Map<String, dynamic>.from(game['players'] ?? {});
    return Scaffold(
      appBar: AppBar(title: const Text('انتظار اللاعبين')),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(children: [
          const Icon(Icons.sports_esports, size: 70),
          const SizedBox(height: 12),
          const Text('رمز اللعبة', style: TextStyle(fontSize: 18)),
          SelectableText(game['gameId'].toString(), style: const TextStyle(fontSize: 30, fontWeight: FontWeight.bold)),
          const SizedBox(height: 20),
          Text('اللاعبون: ${players.length}/${game['maxPlayers']}'),
          const SizedBox(height: 15),
          ...players.values.map((p) => ListTile(leading: _colorCircle(p['color']), title: Text(p['name']?.toString() ?? 'لاعب'))),
          const Spacer(),
          const Text('أرسل الرمز لصديقك حتى يدخل للعبة'),
        ]),
      ),
    );
  }

  Widget _boardScreen(Map<String, dynamic> game) {
    final players = Map<String, dynamic>.from(game['players'] ?? {});
    final myPlayer = Map<String, dynamic>.from(players[_uid] ?? {});
    final myColor = myPlayer['color']?.toString() ?? 'red';
    final dice = ((game['dice'] ?? 0) as num).toInt();
    final myTurn = game['currentPlayer'] == _uid && game['status'] == 'playing';
    final winner = game['winner']?.toString() ?? '';

    return Scaffold(
      appBar: AppBar(title: const Text('🎲 لودو مزاج')),
      body: SafeArea(
        child: Column(children: [
          const SizedBox(height: 6),
          _playersBar(players, game['currentPlayer']?.toString() ?? ''),
          const SizedBox(height: 6),
          Expanded(child: Center(child: AspectRatio(aspectRatio: 1, child: _LudoBoard(players: players, onPieceTap: myTurn && dice > 0 ? (i) => movePiece(game, i) : null)))),
          if (winner.isNotEmpty) _winnerBox(players[winner]),
          if (winner.isEmpty) Text(myTurn ? (dice == 0 ? 'دورك — ارْمِ النرد 🎲' : 'اختار الحجر اللي تريد تحركه') : 'انتظر دورك...', style: const TextStyle(fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          Row(mainAxisAlignment: MainAxisAlignment.center, children: [
            GestureDetector(
              onTap: myTurn && dice == 0 && !_busy ? () => rollDice(game) : null,
              child: Container(width: 70, height: 70, alignment: Alignment.center, decoration: BoxDecoration(color: myTurn ? Colors.deepPurple : Colors.grey.shade800, borderRadius: BorderRadius.circular(18)), child: Text(dice == 0 ? '🎲' : '$dice', style: const TextStyle(fontSize: 30, fontWeight: FontWeight.bold))),
            ),
            const SizedBox(width: 15),
            CircleAvatar(radius: 25, backgroundColor: _colorFor(myColor), child: const Icon(Icons.person, color: Colors.white)),
          ]),
          const SizedBox(height: 12),
        ]),
      ),
    );
  }

  Widget _playersBar(Map<String, dynamic> players, String current) {
    return SizedBox(
      height: 52,
      child: ListView(scrollDirection: Axis.horizontal, children: players.values.map((p) {
        final uid = p['uid']?.toString() ?? '';
        return Container(margin: const EdgeInsets.symmetric(horizontal: 5), padding: const EdgeInsets.symmetric(horizontal: 10), decoration: BoxDecoration(borderRadius: BorderRadius.circular(16), border: Border.all(color: current == uid ? _colorFor(p['color']?.toString() ?? 'red') : Colors.transparent, width: 2)), child: Row(children: [_colorCircle(p['color']), const SizedBox(width: 6), Text(p['name']?.toString() ?? 'لاعب')]));
      }).toList()),
    );
  }

  Widget _winnerBox(dynamic player) {
    final p = player is Map ? Map<String, dynamic>.from(player) : <String, dynamic>{};
    return Padding(padding: const EdgeInsets.all(8), child: Text('🏆 الفائز: ${p['name'] ?? 'لاعب'}', style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)));
  }

  Widget _colorCircle(dynamic value) => Container(width: 22, height: 22, decoration: BoxDecoration(color: _colorFor(value?.toString() ?? 'red'), shape: BoxShape.circle));

  Color _colorFor(String color) {
    switch (color) {
      case 'green': return Colors.green;
      case 'yellow': return Colors.amber;
      case 'blue': return Colors.blue;
      default: return Colors.red;
    }
  }
}

class _LudoBoard extends StatelessWidget {
  final Map<String, dynamic> players;
  final ValueChanged<int>? onPieceTap;

  const _LudoBoard({required this.players, this.onPieceTap});

  static const track = <Offset>[
    Offset(6,1),Offset(6,2),Offset(6,3),Offset(6,4),Offset(6,5),Offset(5,6),Offset(4,6),Offset(3,6),Offset(2,6),Offset(1,6),Offset(0,6),Offset(0,7),Offset(0,8),Offset(1,8),Offset(2,8),Offset(3,8),Offset(4,8),Offset(5,8),Offset(6,9),Offset(6,10),Offset(6,11),Offset(6,12),Offset(6,13),Offset(6,14),Offset(7,14),Offset(8,14),Offset(8,13),Offset(8,12),Offset(8,11),Offset(8,10),Offset(8,9),Offset(9,8),Offset(10,8),Offset(11,8),Offset(12,8),Offset(13,8),Offset(14,8),Offset(14,7),Offset(14,6),Offset(13,6),Offset(12,6),Offset(11,6),Offset(10,6),Offset(9,6),Offset(8,5),Offset(8,4),Offset(8,3),Offset(8,2),Offset(8,1),Offset(8,0),Offset(7,0),Offset(6,0),
  ];

  static const homeSlots = <String, List<Offset>>{
    'red': [Offset(2,2),Offset(4,2),Offset(2,4),Offset(4,4)],
    'green': [Offset(2,10),Offset(4,10),Offset(2,12),Offset(4,12)],
    'yellow': [Offset(10,10),Offset(12,10),Offset(10,12),Offset(12,12)],
    'blue': [Offset(10,2),Offset(12,2),Offset(10,4),Offset(12,4)],
  };

  static const lanes = <String, List<Offset>>{
    'red': [Offset(7,1),Offset(7,2),Offset(7,3),Offset(7,4),Offset(7,5)],
    'green': [Offset(1,7),Offset(2,7),Offset(3,7),Offset(4,7),Offset(5,7)],
    'yellow': [Offset(7,13),Offset(7,12),Offset(7,11),Offset(7,10),Offset(7,9)],
    'blue': [Offset(13,7),Offset(12,7),Offset(11,7),Offset(10,7),Offset(9,7)],
  };

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(builder: (context, box) {
      final cell = box.maxWidth / 15;
      final widgets = <Widget>[Positioned.fill(child: CustomPaint(painter: _BoardPainter(track: track, homeSlots: homeSlots, lanes: lanes)))];
      for (final entry in players.entries) {
        final p = Map<String, dynamic>.from(entry.value);
        final color = p['color']?.toString() ?? 'red';
        final pieces = List<int>.from((p['pieces'] ?? [-1,-1,-1,-1]).map((e) => (e as num).toInt()));
        for (var i = 0; i < 4; i++) {
          final pos = pieces[i];
          final grid = _gridFor(color, pos, i);
          final size = cell * .82;
          widgets.add(Positioned(left: grid.dy * cell + cell * .09, top: grid.dx * cell + cell * .09, width: size, height: size, child: GestureDetector(onTap: entry.key == FirebaseAuth.instance.currentUser?.uid ? () => onPieceTap?.call(i) : null, child: _Piece(color: _colorFor(color), number: i + 1))));
        }
      }
      return Stack(children: widgets);
    });
  }

  Offset _gridFor(String color, int pos, int index) {
    if (pos == -1) return homeSlots[color]![index];
    if (pos >= 0 && pos <= 51) return track[(_startOffset(color) + pos) % 52];
    if (pos >= 52 && pos <= 56) return lanes[color]![pos - 52];
    return const Offset(7,7);
  }

  int _startOffset(String color) {
    switch (color) { case 'green': return 13; case 'yellow': return 26; case 'blue': return 39; default: return 0; }
  }

  Color _colorFor(String color) {
    switch (color) { case 'green': return Colors.green; case 'yellow': return Colors.amber; case 'blue': return Colors.blue; default: return Colors.red; }
  }
}

class _Piece extends StatelessWidget {
  final Color color;
  final int number;
  const _Piece({required this.color, required this.number});

  @override
  Widget build(BuildContext context) => Container(decoration: BoxDecoration(shape: BoxShape.circle, color: color, border: Border.all(color: Colors.white, width: 2), boxShadow: const [BoxShadow(blurRadius: 4)]), child: Center(child: Text('$number', style: const TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.bold))));
}

class _BoardPainter extends CustomPainter {
  final List<Offset> track;
  final Map<String, List<Offset>> homeSlots;
  final Map<String, List<Offset>> lanes;
  _BoardPainter({required this.track, required this.homeSlots, required this.lanes});

  Color c(String color) { switch (color) { case 'green': return Colors.green; case 'yellow': return Colors.amber; case 'blue': return Colors.blue; default: return Colors.red; } }

  @override
  void paint(Canvas canvas, Size size) {
    final cell = size.width / 15;
    final bg = Paint()..color = const Color(0xFF17121F);
    canvas.drawRect(Offset.zero & size, bg);
    _home(canvas, cell, 0, 0, 6, 6, 'red');
    _home(canvas, cell, 0, 9, 6, 6, 'green');
    _home(canvas, cell, 9, 9, 6, 6, 'yellow');
    _home(canvas, cell, 9, 0, 6, 6, 'blue');

    final white = Paint()..color = Colors.white;
    for (var r = 0; r < 15; r++) {
      for (var col = 0; col < 15; col++) {
        final inCross = (r >= 6 && r <= 8) || (col >= 6 && col <= 8);
        final inHome = (r < 6 && col < 6) || (r < 6 && col > 8) || (r > 8 && col < 6) || (r > 8 && col > 8);
        if (inCross && !inHome) {
          final rect = Rect.fromLTWH(col*cell, r*cell, cell, cell);
          canvas.drawRect(rect, Paint()..color = Colors.white.withOpacity(.96));
          canvas.drawRect(rect, Paint()..style = PaintingStyle.stroke..color = Colors.black26..strokeWidth = .6);
        }
      }
    }

    for (final e in lanes.entries) {
      for (final p in e.value) {
        final rect = Rect.fromLTWH(p.dy*cell, p.dx*cell, cell, cell);
        canvas.drawRect(rect, Paint()..color = c(e.key).withOpacity(.65));
      }
    }

    final center = Path()..moveTo(7.5*cell, 6*cell)..lineTo(9*cell, 7.5*cell)..lineTo(7.5*cell, 9*cell)..lineTo(6*cell, 7.5*cell)..close();
    canvas.drawPath(center, Paint()..color = Colors.deepPurple);
    canvas.drawPath(center, Paint()..style = PaintingStyle.stroke..color = Colors.white..strokeWidth = 1.2);

    final safe = <int>{0,8,13,21,26,34,39,47};
    for (final i in safe) {
      final p = track[i];
      final center = Offset((p.dy+.5)*cell, (p.dx+.5)*cell);
      canvas.drawCircle(center, cell*.17, Paint()..color = Colors.black54);
      canvas.drawCircle(center, cell*.10, Paint()..color = Colors.white);
    }
  }

  void _home(Canvas canvas, double cell, int row, int col, int h, int w, String color) {
    final rect = Rect.fromLTWH(col*cell, row*cell, w*cell, h*cell);
    canvas.drawRect(rect, Paint()..color = c(color).withOpacity(.82));
    canvas.drawRect(Rect.fromLTWH((col+1)*cell, (row+1)*cell, (w-2)*cell, (h-2)*cell), Paint()..color = Colors.white.withOpacity(.94));
    for (final p in homeSlots[color]!) {
      canvas.drawCircle(Offset((p.dy+.5)*cell, (p.dx+.5)*cell), cell*.34, Paint()..color = c(color).withOpacity(.25));
    }
  }

  @override
  bool shouldRepaint(covariant _BoardPainter oldDelegate) => false;
}
